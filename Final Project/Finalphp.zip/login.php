<?php
	$hn = 'localhost';
	$un = 'student';
	$pw = '238IOGi3az29disgD';
	$db = 'decryptoid';
?>